const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const preview = document.getElementById("preview");
const placeholder = document.getElementById("cameraPlaceholder");

const startBtn = document.getElementById("startBtn");
const captureBtn = document.getElementById("captureBtn");
const stopBtn = document.getElementById("stopBtn");
const fileInput = document.getElementById("fileInput");

const statusEl = document.getElementById("status");
const results = document.getElementById("results");

let stream = null;
let analyzing = false;

function setStatus(message, type = "") {
  statusEl.textContent = message;
  statusEl.className = "status";
  if (type) statusEl.classList.add(type);
}

async function checkBackend() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();

    if (!data.nvidiaKeyConfigured) {
      setStatus("Backend online, but NVIDIA API key is not configured.", "error");
      return;
    }

    setStatus("Backend connected. Ready to capture.", "success");
  } catch (error) {
    setStatus("Cannot connect to Express backend.", "error");
  }
}

async function startCamera() {
  try {
    setStatus("Requesting camera access...", "loading");

    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: "environment" },
        width: { ideal: 1280 },
        height: { ideal: 720 }
      },
      audio: false
    });

    video.srcObject = stream;
    placeholder.hidden = true;

    startBtn.disabled = true;
    captureBtn.disabled = false;
    stopBtn.disabled = false;

    setStatus("Camera started. Position the item and capture it.", "success");
  } catch (error) {
    console.error(error);
    setStatus(
      "Camera access failed. Check browser permissions and HTTPS/localhost.",
      "error"
    );
  }
}

function stopCamera() {
  if (stream) {
    stream.getTracks().forEach(track => track.stop());
    stream = null;
  }

  video.srcObject = null;
  placeholder.hidden = false;

  startBtn.disabled = false;
  captureBtn.disabled = true;
  stopBtn.disabled = true;

  setStatus("Camera stopped.");
}

function captureImage() {
  if (!stream || !video.videoWidth) {
    setStatus("Camera is not ready.", "error");
    return;
  }

  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;

  const ctx = canvas.getContext("2d");
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

  const imageData = canvas.toDataURL("image/jpeg", 0.82);

  preview.src = imageData;
  preview.hidden = false;

  analyzeImage(imageData);
}

function readUploadedImage(file) {
  if (!file) return;

  if (!file.type.startsWith("image/")) {
    setStatus("Please select an image file.", "error");
    return;
  }

  const reader = new FileReader();

  reader.onload = () => {
    preview.src = reader.result;
    preview.hidden = false;
    analyzeImage(reader.result);
  };

  reader.onerror = () => {
    setStatus("Could not read the image.", "error");
  };

  reader.readAsDataURL(file);
}

async function analyzeImage(imageData) {
  if (analyzing) return;

  analyzing = true;
  captureBtn.disabled = true;

  setStatus("Analyzing image with AI...", "loading");

  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        image: imageData
      })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Analysis failed");
    }

    displayResults(data);
    setStatus("Analysis complete.", "success");
  } catch (error) {
    console.error("Analysis error:", error);

    results.hidden = false;
    document.getElementById("rawJson").textContent = JSON.stringify(
      { error: error.message },
      null,
      2
    );

    setStatus(`Analysis failed: ${error.message}`, "error");
  } finally {
    analyzing = false;
    captureBtn.disabled = !stream;
  }
}

function displayResults(data) {
  results.hidden = false;

  const ewasteBadge = document.getElementById("ewasteBadge");

  ewasteBadge.textContent = data.is_ewaste
    ? "✓ E-WASTE DETECTED"
    : "NOT CLASSIFIED AS E-WASTE";

  ewasteBadge.className =
    "classification " + (data.is_ewaste ? "yes" : "no");

  document.getElementById("item").textContent = data.item;
  document.getElementById("category").textContent = data.category;
  document.getElementById("subcategory").textContent = data.subcategory;
  document.getElementById("condition").textContent = data.condition;

  const confidence = Math.round(Number(data.confidence) * 100);

  document.getElementById("confidenceText").textContent = `${confidence}%`;
  document.getElementById("confidenceBar").style.width = `${confidence}%`;

  document.getElementById("description").textContent = data.description;

  document.getElementById("rawJson").textContent = JSON.stringify(
    data,
    null,
    2
  );

  results.scrollIntoView({
    behavior: "smooth",
    block: "start"
  });
}

startBtn.addEventListener("click", startCamera);
stopBtn.addEventListener("click", stopCamera);
captureBtn.addEventListener("click", captureImage);
fileInput.addEventListener("change", event => {
  readUploadedImage(event.target.files[0]);
});

window.addEventListener("beforeunload", stopCamera);

checkBackend();